export default function Button({ label, variant = "primary", disabled }) {
  const colors = {
    primary: "blue",
    secondary: "gray",
  };

  return (
    <button
      style={{
        background: colors[variant],
        color: "white",
        padding: "10px",
        border: "none",
      }}
      disabled={disabled}
    >
      {label}
    </button>
  );
}