export default function ProductCard({ title, price, image, badge }) {
  return (
    <div
      style={{
        border: '1px solid #e0e0e0',
        borderRadius: '8px',
        padding: '16px',
        width: '200px',
        position: 'relative',
        boxShadow: '0 2px 8px rgba(0,0,0,0.08)',
        fontFamily: 'sans-serif',
      }}
    >
      {badge && (
        <span
          style={{
            position: 'absolute',
            top: '8px',
            right: '8px',
            background: '#e53935',
            color: 'white',
            fontSize: '11px',
            padding: '2px 8px',
            borderRadius: '12px',
          }}
        >
          {badge}
        </span>
      )}
      {image && (
        <img
          src={image}
          alt={title}
          style={{ width: '100%', borderRadius: '4px', marginBottom: '8px' }}
        />
      )}
      <h3 style={{ margin: '0 0 8px', fontSize: '16px' }}>{title}</h3>
      <p style={{ margin: 0, fontWeight: 'bold', color: '#2e7d32' }}>₹{price}</p>
    </div>
  );
}
