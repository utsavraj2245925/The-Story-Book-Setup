import Input from './input';

export default {
  title: 'MyComponents/Input',
  component: Input,
  parameters: {
    layout: 'centered',
  },
  tags: ['autodocs'],
  argTypes: {
    placeholder: { control: 'text' },
    disabled: { control: 'boolean' },
    type: {
      control: 'select',
      options: ['text', 'email', 'password', 'number'],
    },
  },
};

export const Default = {
  args: {
    placeholder: 'Enter text...',
    type: 'text',
    disabled: false,
  },
};

export const Email = {
  args: {
    placeholder: 'Enter email...',
    type: 'email',
    disabled: false,
  },
};

export const Disabled = {
  args: {
    placeholder: 'Disabled input',
    type: 'text',
    disabled: true,
  },
};
