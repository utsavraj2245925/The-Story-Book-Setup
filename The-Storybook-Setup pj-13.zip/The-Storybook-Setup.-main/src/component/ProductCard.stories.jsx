import ProductCard from './ProductCard';

export default {
  title: 'MyComponents/ProductCard',
  component: ProductCard,
  parameters: {
    layout: 'centered',
  },
  tags: ['autodocs'],
  argTypes: {
    title: { control: 'text' },
    price: { control: 'number' },
    image: { control: 'text' },
    badge: {
      control: 'select',
      options: ['', 'New', 'Sale', 'Hot'],
    },
  },
};

export const Default = {
  args: {
    title: 'Wireless Headphones',
    price: 1999,
    image: '',
    badge: '',
  },
};

export const WithBadge = {
  args: {
    title: 'Running Shoes',
    price: 3499,
    image: '',
    badge: 'Sale',
  },
};

export const NewProduct = {
  args: {
    title: 'Smart Watch',
    price: 8999,
    image: '',
    badge: 'New',
  },
};
