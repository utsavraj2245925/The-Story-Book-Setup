export default function Input({ placeholder, type = 'text', disabled = false }) {
  return (
    <input
      placeholder={placeholder}
      type={type}
      disabled={disabled}
      style={{
        padding: '8px 12px',
        border: '1px solid #ccc',
        borderRadius: '4px',
        fontSize: '14px',
        opacity: disabled ? 0.5 : 1,
        cursor: disabled ? 'not-allowed' : 'text',
      }}
    />
  );
}
